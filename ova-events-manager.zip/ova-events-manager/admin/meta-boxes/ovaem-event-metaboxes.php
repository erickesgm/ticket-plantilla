<?php 

if( !defined( 'ABSPATH' ) ) exit();

if( !class_exists( 'OVAEM_Event_Metaboxes' ) ){

	class OVAEM_Event_Metaboxes{

		public static function render(){
			require_once( OVAEM_PLUGIN_PATH. '/admin/views/ovaem-metabox-event.php' );
		}

		public static function save($post_id, $post_data){
			



			$prefix = OVAEM_Settings::$prefix;

			if( empty($post_data) ) exit();
			
			if( array_key_exists($prefix.'_featured', $post_data) == false ){
				$post_data[$prefix.'_featured'] = '';
			}else{
				$post_data[$prefix.'_featured'] = 'checked';
			}


			// Check schedule exits
			$schedule_date = isset( $post_data[$prefix.'_schedule_date'] ) ? $post_data[$prefix.'_schedule_date'] : '';

			if( $schedule_date ){

				// Make Speakers metabox to store all speaker in each plan
				$speakers_arr =  '';
				$plans = isset( $post_data[$prefix.'_schedule_plan'] ) ? $post_data[$prefix.'_schedule_plan'] : array();

				if( !empty( $plans ) ){
					foreach ($plans as $key_plan => $value_plan) {
						if( $value_plan ){
							foreach ($value_plan as $key => $value) {
								$speakers_arr .= $value['speakers'];
							}	
						}
					}
					$post_data['speakers'] = $speakers_arr;
				}
				

			}else{
				$post_data[$prefix.'_schedule_date'] = '';
			}



			// Check sponsor exits
			$sponsor_level = isset( $post_data[$prefix.'_sponsor_level'] ) ? $post_data[$prefix.'_sponsor_level'] : '';
			if( !$sponsor_level ){
				$post_data[$prefix.'_sponsor_level'] = '';
			}

			// Check gallery exits
			if( !isset( $post_data['ovaem_gallery_id'] ) ){
				$post_data['ovaem_gallery_id'] = '';
			}
			
			$ticket_field = isset( $post_data[$prefix.'_ticket'] ) ? $post_data[$prefix.'_ticket'] : '';
			if( !$ticket_field ){
				$post_data[$prefix.'_ticket'] = '';
			}

			// Check faq exits
			$faq_level = isset( $post_data[$prefix.'_faq_title'] ) ? $post_data[$prefix.'_faq_title'] : '';
			
			if( !$faq_level ){
				$post_data[$prefix.'_faq_title'] = '';
			}

			foreach ($post_data as $key => $value) {

				if($key == $prefix.'_date_start_time') $value = strtotime($value);
				if($key == $prefix.'_date_end_time') $value = strtotime($value);
				
				update_post_meta( $post_id, $key, $value );	
			}

			
		}





	}

}



?>