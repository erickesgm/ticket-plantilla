<?php 

if( !defined( 'ABSPATH' ) ) exit();

if( !class_exists( 'OVAEM_coupon_Metaboxes' ) ){

	class OVAEM_coupon_Metaboxes{

		public static function render(){
			
			if( !current_user_can( 'administrator' ) ) return false;
			require_once( OVAEM_PLUGIN_PATH. '/admin/views/ovaem-metabox-coupon.php' );
		}

		public static function save($post_id, $post_data){

			$prefix = OVAEM_Settings::$prefix;

			if( empty($post_data) ) exit();

			// if( array_key_exists($prefix.'_speaker_social', $post_data) == false )   $post_data[$prefix.'_speaker_social'] = '';
			
			foreach ($post_data as $key => $value) {
				
				if($key == $prefix.'_coupon_start_date') $value = strtotime($value);
				if($key == $prefix.'_coupon_end_date') $value = strtotime($value);

				update_post_meta( $post_id, $key, $value );	
			}
			
			
		}

	}

}



