<?php 
defined( 'ABSPATH' ) || exit();

if( !class_exists( 'OVAEM_Assets' ) ){
	class OVAEM_Assets{

		public function __construct(){

			add_action( 'wp_enqueue_scripts', array( $this, 'ovaem_enqueue_scripts' ), 10 ,0 );
			

		}
		

		public function ovaem_enqueue_scripts(){
			

			// Date Time Picker
			wp_enqueue_script('datetimepicker_js', OVAEM_PLUGIN_URI.'assets/libs/datetimepicker/jquery.datetimepicker.full.min.js', array('jquery'), null, true );
			wp_enqueue_script('validate', OVAEM_PLUGIN_URI.'assets/libs/validate/jquery.validate.min.js', array('jquery'), null, true );
			

			// Ajax Checkout Event
			wp_enqueue_script('ajax-script', OVAEM_PLUGIN_URI.'assets/js/frontend/checkout_event.js',array('jquery'),null,true);
			wp_localize_script( 'ajax-script', 'ajax_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );			

			

			// recaptcha
			if( ovaem_show_captcha() ){
				$captcha_sitekey = OVAEM_Settings::captcha_sitekey();
				wp_enqueue_script( 'recaptcha', 'https://www.google.com/recaptcha/api.js?render='.$captcha_sitekey, array('jquery'), null, true );
			}

			wp_enqueue_script( 'ovaem_script', OVAEM_PLUGIN_URI.'assets/js/frontend/ovaem_script.js', array('jquery'), null, true );
			
			// Date Time Picker
			wp_enqueue_style('datetimepicker_css', OVAEM_PLUGIN_URI.'assets/libs/datetimepicker/jquery.datetimepicker.css', array(), null );

			wp_enqueue_style( 'ovaem_style', OVAEM_PLUGIN_URI.'assets/css/frontend/ovaem_style.css', array(), null );
			
			
			
			
		}


	}
	new OVAEM_Assets();
}
