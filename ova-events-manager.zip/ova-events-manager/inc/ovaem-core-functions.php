<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', 'ovaem_theme_setup' );
function ovaem_theme_setup() {
	add_image_size( 'd_img', 370, 222, true );
	add_image_size( 'm_img', 640, 384, true );
}



if( !function_exists( 'ovaem_locate_template' ) ){
	function ovaem_locate_template( $template_name, $template_path = '', $default_path = '' ) {
		
		// Set variable to search in ovaem-templates folder of theme.
		if ( ! $template_path ) :
			$template_path = 'ovaem-templates/';
		endif;

		// Set default plugin templates path.
		if ( ! $default_path ) :
			$default_path = OVAEM_PLUGIN_PATH . 'templates/'; // Path to the template folder
		endif;

		// Search template file in theme folder.
		$template = locate_template( array(
			$template_path . $template_name
			
		) );

		// Get plugins template file.
		if ( ! $template ) :
			$template = $default_path . $template_name;
		endif;

		return apply_filters( 'ovaem_locate_template', $template, $template_name, $template_path, $default_path );
	}

}


function ovaem_get_template( $template_name, $args = array(), $tempate_path = '', $default_path = '' ) {
	
	if ( is_array( $args ) && isset( $args ) ) :
		extract( $args );
	endif;

	$template_file = ovaem_locate_template( $template_name, $tempate_path, $default_path );

	if ( ! file_exists( $template_file ) ) :
		_doing_it_wrong( __FUNCTION__, sprintf( '<code>%s</code> does not exist.', $template_file ), '1.0.0' );
		return;
	endif;

	include $template_file;

}


function ovaem_pagination_theme($ovaem_query = null) {


	/** Stop execution if there's only 1 page */
	if($ovaem_query != null){
		if( $ovaem_query->max_num_pages <= 1 )
			return;	
	}else if( $wp_query->max_num_pages <= 1 )
	return;


	if( is_front_page() ){
		$paged = get_query_var( 'page' ) ? absint( get_query_var( 'page' ) ) : 1;	
	}else{
		$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	}
	


	

	if($ovaem_query!=null){
		$max   = intval( $ovaem_query->max_num_pages );
	}else{
		$max   = intval( $wp_query->max_num_pages );	
	}
	

	/** Add current page to the array */
	if ( $paged >= 1 )
		$links[] = $paged;

	/** Add the pages around the current page to the array */
	if ( $paged >= 3 ) {
		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}

	if ( ( $paged + 2 ) <= $max ) {
		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}


	echo '<div class="ovaem_pagination"><ul class="pagination">' . "\n";

	/** Previous Post Link */
	if ( get_previous_posts_link() )
		printf( '<li class="prev page-numbers">%s</li>' . "\n", get_previous_posts_link('<i class="arrow_carrot-left"></i>') );

	/** Link to first page, plus ellipses if necessary */
	if ( ! in_array( 1, $links ) ) {
		$class = 1 == $paged ? ' class="active"' : '';

		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( 1 ) ), '1' );

		if ( ! in_array( 2, $links ) )
			echo '<li>...</li>';
	}

	/** Link to current page, plus 2 pages in either direction if necessary */
	sort( $links );
	foreach ( (array) $links as $link ) {
		$class = $paged == $link ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $link ) ), $link );
	}

	/** Link to last page, plus ellipses if necessary */
	if ( ! in_array( $max, $links ) ) {
		if ( ! in_array( $max - 1, $links ) )
			echo '<li>...</li>' . "\n";

		$class = $paged == $max ? ' class="active"' : '';
		printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, esc_url( get_pagenum_link( $max ) ), $max );
	}

	/** Next Post Link */
	if ( get_next_posts_link() )
		printf( '<li class="next page-numbers">%s</li>' . "\n", get_next_posts_link('<i class="arrow_carrot-right"></i>') );

	echo '</ul></div>' . "\n";

}








add_action( 'widgets_init', 'ovaem_register_widget', 11 );
function ovaem_register_widget() {
	$ovaem_sidebar = array(
		'name' => esc_html__( 'Event Sidebar', 'ovaem-events-manager'),
		'id' => "ovaem-sidebar",
		'class' => '',
		'before_widget' => '<div id="%1$s" class="event_widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h3 class="title">',
		'after_title' => "<span class=\"one\"></span><span class=\"two\"></span><span class=\"three\"></span><span class=\"four\"></span><span class=\"five\"></span></h3>",
	);
	register_sidebar( $ovaem_sidebar );
}


function shorten_string($string, $wordsreturned)
{
	$retval = $string;
	$string = preg_replace('/(?<=\S,)(?=\S)/', ' ', $string);
	$string = str_replace("\n", " ", $string);
	$array = explode(" ", $string);
	if (count($array)<=$wordsreturned)
	{
		$retval = $string;
	}
	else
	{
		array_splice($array, $wordsreturned);
		$retval = implode(" ", $array)." . . .";
	}
	return $retval;
}


/* Display Format of Price */
function ovaem_format_price($price, $cur){
	$currency_position = OVAEM_Settings::currency_position();
	switch ($currency_position) {
		case 'left':
		$price_format = '<span class="cur">'.$cur.'</span><span class="amount">'.$price.'</span>';
		break;
		case 'right':
		$price_format = '<span class="amount">'.$price.'</span><span class="cur">'.$cur.'</span>';
		break;	
		case 'left_space':
		$price_format = '<span class="cur">'.$cur.'</span>&nbsp;<span class="amount">'.$price.'</span>';
		break;

		default:
		$price_format = '<span class="amount">'.$price.'</span>&nbsp;<span class="cur">'.$cur.'</span>';
		break;
	}
	return $price_format;
}


function ova_wp_mail_from(){
	return get_option('admin_email');
}

function ova_wp_mail_from_name(){
	return esc_html__(" Register Event Success", 'ovaem-events-manager');
}




// Breadcrumbs
add_action( 'ovaem_event_breadcrumbs', 'ovaem_event_breadcrumbs' );
function ovaem_event_breadcrumbs(){
	
}


// Title
add_action( 'ovaem_event_title', 'ovaem_event_title' );
function ovaem_event_title(){
	ovaem_get_template( 'loop/title.php' );
}



// Thumbnail
add_action( 'ovaem_event_thumbnail', 'ovaem_event_thumbnail' );
function ovaem_event_thumbnail(){
	ovaem_get_template( 'loop/thumbnail.php' );
}




// Schedule
add_action( 'ovaem_event_schedule', 'ovaem_event_schedule' );
function ovaem_event_schedule(){
	ovaem_get_template( 'loop/schedule.php' );
}

// Add to cart
add_action( 'ovaem_add_to_cart', 'ovaem_add_to_cart' );
function ovaem_add_to_cart(){
	ovaem_get_template( 'cart/add-to-cart.php' );
}

// Gallery
add_action( 'ovaem_event_gallery', 'ovaem_event_gallery' );
function ovaem_event_gallery(){
	ovaem_get_template( 'loop/gallery.php' );
}

add_action( 'ovaem_event_gallery_modern', 'ovaem_event_gallery_modern' );
function ovaem_event_gallery_modern(){
	ovaem_get_template( 'loop/gallery_modern.php' );
}

// Map
add_action( 'ovaem_event_map', 'ovaem_event_map' );
function ovaem_event_map(){
	ovaem_get_template( 'loop/map.php' );
}

// Ticket
add_action( 'ovaem_event_ticket', 'ovaem_event_ticket' );
function ovaem_event_ticket(){
	ovaem_get_template( 'loop/ticket.php' );
}

// organizer
add_action( 'ovaem_event_organizer', 'ovaem_event_organizer' );
function ovaem_event_organizer(){
	ovaem_get_template( 'loop/organizer.php' );
}

// Speakers
add_action( 'ovaem_event_speaker', 'ovaem_event_speaker' );
function ovaem_event_speaker(){
	ovaem_get_template( 'loop/speaker.php' );
}

//Sponsor
add_action( 'ovaem_event_sponsor', 'ovaem_event_sponsor' );
function ovaem_event_sponsor(){
	ovaem_get_template( 'loop/sponsor.php' );
}

// Tag
add_action( 'ovaem_event_tag', 'ovaem_event_tag' );
function ovaem_event_tag(){
	ovaem_get_template( 'loop/tag.php' );
}

// Related
add_action( 'ovaem_event_related', 'ovaem_event_related' );
function ovaem_event_related(){
	ovaem_get_template( 'loop/related.php' );
}

// Social Share
add_action( 'ovaem_event_social', 'ovaem_event_social' );
function ovaem_event_social(){
	ovaem_get_template( 'loop/social.php' );
}

// Frontend Submit
add_action( 'ovaem_frontend_submit', 'ovaem_frontend_submit' );
function ovaem_frontend_submit(){
	ovaem_get_template( 'frontend-submit.php' );
}

// Schema
add_action( 'ovaem_single_event_schema', 'ovaem_single_event_schema' );
function ovaem_single_event_schema(){
	ovaem_get_template( 'single-event-schema.php' );
}

// FAQ
add_action( 'ovaem_event_faq', 'ovaem_event_faq' );
function ovaem_event_faq(){
	ovaem_get_template( 'loop/faq.php' );
}




// Get Plugin Version
function ovaem_plugin_data(){
	$plugin_file = OVAEM_PLUGIN_PATH.'/ova-events-manager.php';
	return get_plugin_data( $plugin_file, $markup = true, $translate = true );
}

// Get cer attach mail by package_id, event_id
function get_cer_attach( $event_id, $package_id ){

	$package_id = isset($package_id) ? str_replace( "ovaminus", "_", urldecode($package_id) ) : '';

	$cer_file_attach = '';

	$prefix = OVAEM_Settings::$prefix;
	$ticket_field = $prefix.'_ticket';
	$tickets = get_post_meta( $event_id , $ticket_field, true );
	if( $tickets ){
		foreach ($tickets as $key => $ticket) {
			
			$ticket_package_id = isset($ticket["package_id"]) ? str_replace( "ovaminus", "_", urldecode($ticket["package_id"]) ) : '';

			if( $ticket_package_id == $package_id ){
				$pdf_attach = $ticket['pdf_attach'];

				if( $pdf_attach ){
					$cer_file_attach =  get_attached_file( $pdf_attach );
					break;
				}
			}
		}
	}
	return $cer_file_attach;
}


/***** Posts Per Page Archive *****/
function em4u_archive_posts_per_page ( $query ) {

	$event_post_type_slug = OVAEM_Settings::event_post_type_slug();
	$slug_taxonomy_name = OVAEM_Settings::slug_taxonomy_name();
	$search = isset( $_REQUEST['search'] ) ? esc_html( $_REQUEST['search'] ) : '';
	$post_type = isset($_REQUEST['post_type'] ) ? esc_html( $_REQUEST['post_type'] ) : get_post_type();

	if ( ! is_admin() ) {
		
		if( ( is_tax( $slug_taxonomy_name ) ||  ( isset( $_REQUEST[$slug_taxonomy_name] ) && get_query_var( $slug_taxonomy_name, '' ) != '' ) ) 
			|| ( is_tax( 'event_tags' ) ||  ( isset( $_REQUEST['event_tags'] ) && get_query_var( 'event_tags', '' ) != '' ) )
			|| ( $post_type == $event_post_type_slug && ( $search != '' || is_post_type_archive( $event_post_type_slug ) || is_tax( $slug_taxonomy_name ) ) )
			|| is_page_template( 'templates/upcoming-event.php' )
			|| is_page_template( 'templates/past-event.php' )
			|| is_page_template( 'templates/featured-event.php' )

		){
			$query->set('posts_per_page', OVAEM_Settings::ovaem_list_post_per_page() );
		}

	}

};
add_action( 'pre_get_posts', 'em4u_archive_posts_per_page' );


//function sub string in word
function sub_string_word ($content = "", $number = 0) {
	
	$content = sanitize_text_field($content);
	
	$number = (int)$number;
	
	if (empty($content) || empty($number)) return $content;
	
	$sub_string = mb_substr($content, 0, $number );
	
	if( $sub_string == $content ) return $content;
	
	return $sub_string.'...';
}


if ( !function_exists('ovaem_pagination_ajax') ) {
	function ovaem_pagination_ajax( $total, $limit, $current  ) {

		$pages = ceil($total / $limit);

		if ($pages > 1) {
			?>
			<ul class="pagination">

				<?php if( $current > 1 ) { ?>
					<li><a href="#" data-paged="<?php echo esc_attr($current - 1); ?>" class="prev page-numbers" ><?php esc_html_e( 'Previous', 'ovaem-events-manager' ); ?></a></li>
				<?php } ?>

				<?php for ($i = 1; $i < $pages+1; $i++) { ?>
					<li class="<?php echo esc_attr( ($current == $i) ? 'active' : '' ); ?>"><a href="#" data-paged="<?php echo esc_attr($i); ?>" class="page-numbers"><?php echo esc_html($i); ?></a></li>
				<?php } ?>

				<?php if( $current < $pages ) { ?>
					<li><a href="#" data-paged="<?php echo esc_attr($current + 1); ?>" class="next page-numbers" ><?php esc_html_e( 'Next', 'ovaem-events-manager' ); ?></a></li>
				<?php } ?>

			</ul>
			<?php
		}
	}
}


if ( !function_exists('ovaem_show_captcha') ) {
	function ovaem_show_captcha() {
		if( apply_filters( 'ovaem_show_captcha', true ) && OVAEM_Settings::captcha_sitekey() && OVAEM_Settings::captcha_serectkey() ){
			return true;
		}
		return false;
	}
}


// Get full list languge calendar
if (! function_exists( 'ovaem_get_calendar_language' )) {
   function ovaem_get_calendar_language() {

      $symbols = array(
         'en-GB' => 'English/UK',
         'ar' => 'Arabic',
         'az' => 'Azerbaijani',
         'bg' => 'Bulgarian',
         'bs' => 'Bosnian',
         'ca' => 'Inicialització',
         'ch' => 'Simplified Chinese',
         'cs' => 'Czech',
         'da' => 'Danish',
         'de' => 'German',
         'el' => 'Greek',
         'en' => 'English',
         'es' => 'Spanish',
         'et' => 'Eesti',
         'eu' => 'Euskara',
         'fa'	=> 'Persian',
         'fi' => 'Finnish',
         'fr' => 'French',
         'gl' => 'Galician',
         'he' => 'Hebrew',
         'hr' => 'Croatian',
         'hu' => 'Hungarian',
         'id' => 'Indonesian',
         'it' => 'Italian',
         'ja' => 'Japanese',
         'ko' => 'Korean',
         'kr' => 'Korean',
         'lt' => 'Lithuanian',
         'lv' => 'Latvian',
         'mk' => 'Macedonian',
         'mn' => 'Mongolian',
         'nl' => 'Dutch',
         'no' => 'Norwegian',
         'pl' => 'Polish',
         'pt' => 'Portuguese',
         'pt-BR' => 'Brazilian',
         'ro' => 'Romanian',
         'ru' => 'Russian',
         'se' => 'Swedish',
         'sk' => 'Slovak',
         'sl' => 'Slovenian',
         'sq' => 'Albanian',
         'sr' => 'Serbian',
         'sr-YU' => 'Serbian (Srpski)',
         'sv' => 'Swedish',
         'th' => 'Thai',
         'tr' => 'Turkish',
         'uk' => 'Ukrainian',
         'vi' => 'Vietnamese',
         'zh' => 'Chinese',
         'zh-TW' => 'Chinese (Taiwan)',
      );

      return apply_filters( 'ovaem_get_calendar_language', $symbols );
   }
}
