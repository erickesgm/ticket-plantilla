<?php if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('OVA_Location')) {
	class OVA_Location {

		public function __construct() {

			add_action('wp_ajax_ova_load_city', array($this, 'ova_load_city'));
			add_action('wp_ajax_nopriv_ova_load_city', array($this, 'ova_load_city'));

		}
 
		public static function ova_load_city() {

			$city_html = '<option value="">' . esc_html__(' All Cities', 'ovaem-events-manager') . '</option>';

			$data = $_POST['data'];

			$country = $data['country'] ? sanitize_text_field($data['country']) : '';

			$term_country = get_term_by('slug', $country, 'location');

			$country_info = get_term_children($term_country->term_id, 'location');

			/* No States selected, so reset state list */
			if ($term_country == false) { 

				$parent_terms = get_terms( 'location', array( 'parent' => 0, 'orderby' => 'slug', 'hide_empty' => false ) ); 

				foreach ( $parent_terms as $pterm ) {
					$terms = get_terms( 'location', array( 'parent' => $pterm->term_id, 'orderby' => 'slug', 'hide_empty' => false ) );

					foreach ( $terms as $term ) { 
						$city_html .= '<option value="' . $term->slug . '">' . $term->name . '</option>';
					}
				}

			} else {
				foreach ($country_info as $value) {

					$term_city = get_term_by('id', $value, 'location');

					$city_html .= '<option value="' . $term_city->slug . '">' . $term_city->name . '</option>';
				}
			}

			echo $city_html;
			wp_die();

		}

	}
	new OVA_Location();
}
