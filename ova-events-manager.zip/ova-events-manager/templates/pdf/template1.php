<?php 
// Get Info ticket
$ticket = $args['ticket']; ?>

<span style="color: <?php echo $ticket['text_color']; ?>; font-size: <?php echo $ticket["event_name_font_size"]; ?>">
	<?php echo $ticket['event_name']; ?>
</span>

<br><br>

<div style="color: <?php echo $ticket['label_color']; ?>; font-size: <?php echo $ticket['label_size']; ?>">
	<b><?php esc_html_e( 'Time', 'ovaem-events-manager' ); ?>:</b>
</div>

<div style="color: <?php echo $ticket['text_color']; ?>; font-size: <?php echo $ticket['text_size']; ?> ">
	<?php echo $ticket['time']; ?>
</div>


<br>

<div style="color: <?php echo $ticket['label_color']; ?>; font-size: <?php echo $ticket['label_size']; ?>">
	<b><?php esc_html_e( 'Venue', 'ovaem-events-manager' ); ?>:</b>
</div>
<div style="color: <?php echo $ticket['text_color']; ?>; font-size: <?php echo $ticket['text_size']; ?> ">
	<?php echo $ticket['venue']; ?>
	<br>
	<?php echo $ticket['address']; ?>
</div>


<br>




<table>
	<tbody>
	  <tr>
		
		<td class="left" style="padding-right: 45px;">
	  		<barcode code="<?php echo $ticket['qrcode_str']; ?>" type="QR" disableborder="1" />
	  	</td>
		

	  	<td class="right">

	  		#<?php echo $ticket['qrcode_str']; ?>

	  		<br><br>

	  		<div>
				<b style="color: <?php echo $ticket['label_color']; ?>; font-size: <?php echo $ticket['label_size']; ?>">
					<?php esc_html_e( 'Order Info', 'ovaem-events-manager' ); ?>:
				</b>
				<span style="color: <?php echo $ticket['text_color']; ?>; font-size: <?php echo $ticket['text_size']; ?> ">
					<?php echo $ticket['holder_ticket']; ?>
				</span>
			</div>
			

			<br>
			
			<div>
				<b style="color: <?php echo $ticket['label_color']; ?>; font-size: <?php echo $ticket['label_size']; ?>">
					<?php esc_html_e( 'Package', 'ovaem-events-manager' ); ?>:
				</b>
				<span style="color: <?php echo $ticket['text_color']; ?>; font-size: <?php echo $ticket['text_size']; ?> ">
					<?php echo $ticket['package']; ?>
				</span>
			</div>
			

	  	</td>
	  	

	  </tr>

	</tbody>

</table>




