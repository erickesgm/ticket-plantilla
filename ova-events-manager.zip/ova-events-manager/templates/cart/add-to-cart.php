<?php $post_type = OVAEM_Settings::event_post_type_slug(); ?>
<a href="<?php echo home_url('/').'?post_type='.$post_type.'&action=ovaem_add_to_cart&id='.get_the_id() ?>" class="ovatheme_btn"><?php esc_html_e( 'Add To Cart' ,'ovaem-events-manager' ); ?></a>
		


